//
//  PersonajesDetailView.swift
//  FotoNasa
//
//  Created by Alumno on 06/05/24.
//

import SwiftUI

struct PersonajesDetailView: View {
    var personaje: Personaje
    
    var body: some View {
        VStack(alignment: .center){
            Text("nombre: \(personaje.name)")
                .font(.title)
            AsyncImage(url: URL(string: personaje.image))
                .scaledToFit()
                .frame(height: 200)
                .clipped()
            Text("Estatus: \(personaje.status)")
            
        }
    }
}

