//
//  PersonajesDetailView.swift
//  FotoNasa
//
//  Created by Alumno on 06/05/24.
//

import SwiftUI

struct PersonajesRow: View {
    var personaje: Personaje
    
    var body: some View {
        VStack{
            Text(personaje.name)
            AsyncImage(url: URL(string: personaje.image))
                .scaledToFit()
                .frame(height: 400)
                .clipped()
            
        }
    }
}

