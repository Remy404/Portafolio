//
//  ContentView.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 05/03/24.
//

import SwiftUI

struct PersonajesView: View {
    
    @State var PersonajeVM = PhotoViewModel()
    
    var body: some View {
    
        NavigationStack{
            List(PersonajeVM.arrPersonajes) { item in
                NavigationLink {
                    PersonajesDetailView(personaje: item)
                } label: {
                    PersonajesRow(personaje: item)
                }
            }
            .task{
                do {
                    try await PersonajeVM.getPersonajesData()
                } catch {
                    print("Error", error)
                }
            }
            
        }
        
        
        
    }
}

#Preview {
    PersonajesView()
}
