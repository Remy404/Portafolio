import SwiftUI
import Foundation

struct catmodel: Hashable, Codable, Identifiable {
    var id: Int
    var name: String
    var color: String
    var especie: String
    var edad: Int
    
    private var imageName: String
        var image: Image {
            Image(imageName)
    }
}
