import SwiftUI

struct listRow: View {
    var cat: catmodel
    
    var body: some View {
        HStack {
            cat.image
                .resizable()
                .frame(width: 50, height: 50)
            Text(cat.name)
            
            Spacer()
        }
    }
}

#Preview {
    Group {
        listRow(cat: catmodels[0])
        listRow(cat: catmodels[1])
    }
}
