//
//  ContentView.swift
//  Gatos
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            catList()
        }
    }
}

#Preview {
    ContentView()
}
