import SwiftUI

struct catList: View {
    var body: some View {
        NavigationSplitView {
            List(catmodels) { cat in
                NavigationLink {
                    listRow(cat: cat)
                } label: {
                    listRow(cat: cat)
                }
            }
            .navigationTitle("Cats")
        } detail: {
            Text("Select a Cat")
        }
    }
}

#Preview {
    catList()
}
