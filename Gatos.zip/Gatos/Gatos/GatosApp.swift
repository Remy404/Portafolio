//
//  GatosApp.swift
//  Gatos
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI

@main
struct GatosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
