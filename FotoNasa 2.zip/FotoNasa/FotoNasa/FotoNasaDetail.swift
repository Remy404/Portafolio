//
//  FotoNasaDetail.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 05/03/24.
//

import SwiftUI

struct FotoNasaDetail: View {
    
    var foto : Photo
    
    var body: some View {
        VStack{
            Text(foto.title)
            AsyncImage(url: URL(string: foto.url))
                .scaledToFit()
                .frame(height: 200)
                .clipped()
            
            Text(foto.explanation)
            
        }
    }
}

#Preview {
    FotoNasaDetail( foto: Photo(title: "Foto", explanation: "Descripcion Foto", url: "https://apod.nasa.gov/apod/image/0211/leonid2002_sapp1.jpg"))
}
