//
//  PersonajesView.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 07/03/24.
//

import SwiftUI

struct PersonajesView: View {
    
    @State var photoVM = PhotoViewModel()
    
    var body: some View {
        NavigationStack{
            
        }
        List(photoVM.arrPersonajes){ item in
            Text(item.name)
            AsyncImage(url: URL(string: item.image))
        }
        .task{
            do{
                try await photoVM.getPersonajesData()
                
            } catch {
                print("Error al cargar los personajes")
            }
            
        }
        
    }
}

#Preview {
    PersonajesView()
}
