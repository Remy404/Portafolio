//
//  MainView.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 07/03/24.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        
        TabView{
            FotosView()
                .tabItem {
                    Label("Fotos Nasa", systemImage: "moonphase.waxing.crescent")
                }
            
            PersonajesView()
                .tabItem {
                    Label("Rick&morty", systemImage: "person.fill")
                }
            
            
        }
        
    }
}

#Preview {
    MainView()
}
