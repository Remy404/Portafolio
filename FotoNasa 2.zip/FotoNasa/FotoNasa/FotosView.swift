//
//  ContentView.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 05/03/24.
//

import SwiftUI

struct FotosView: View {
    
    @State var PhotoVM = PhotoViewModel()
    
    var body: some View {
    
        NavigationStack{
            List(PhotoVM.arrPhotos) { item in
                NavigationLink {
                    FotoNasaDetail(foto: item)
                } label: {
                    FotoNasaRow(foto: item)
                }
            }
            .task{
                do {
                    try await PhotoVM.getPhotoData()
                } catch {
                    print("Error", error)
                }
            }
            
        }
        
        
        
    }
}

#Preview {
    FotosView()
}
