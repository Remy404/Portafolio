//
//  PersonajesDetailView.swift
//  FotoNasa
//
//  Created by Alumno on 06/05/24.
//

import SwiftUI

struct PersonajesDetailView: View {
    var personaje: Personaje
    var body: some View {
        VStack{
            Text(personaje.name)
            AsyncImage(url: URL(string: personaje.image))
                .scaledToFit()
                .frame(height: 200)
                .clipped()
            
            Text(personaje.status)
            
        }
    }
}
