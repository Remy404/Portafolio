//
//  FotoNasaApp.swift
//  FotoNasa
//
//  Created by Elvia Itzamná Rosas on 05/03/24.
//

import SwiftUI

@main
struct FotoNasaApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
