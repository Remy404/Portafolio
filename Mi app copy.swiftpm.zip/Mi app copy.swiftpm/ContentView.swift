//
//  ContentView.swift
//  practica
//
//  Created by Alumno on 01/05/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       
        
        
        tabViewView()
    }
    
    
}

#Preview {
    ContentView()
}
