//
//  TabView.swift
//  practica
//
//  Created by Alumno on 01/05/24.
//

import SwiftUI

struct tabViewView: View {
    var body: some View {
        TabView{
            VStack(alignment: .leading, spacing: 20){
                whoView()
            }
                .tabItem {
                    Image(systemName: "person.crop.circle.badge.questionmark")
                    Text("About me")
                }
            
            curriculumView()
            
                .tabItem {
                    Image(systemName: "square.and.pencil")
                    Text("Work Experience")
                }
            
        }
    }
}

struct tabViewView_Preview: PreviewProvider {
    static var previews: some View {
        tabViewView()
        
    }
}
