

import SwiftUI

struct curriculumView: View {
    var body: some View {
        
        VStack(alignment: .leading, spacing: 20){
            Text("Work experience")
                .padding(.top, 20)
                .font(.largeTitle)
            HStack(alignment: .top){
                VStack(alignment: .leading, spacing: 20){
                    Text("Studied Computer Science at UAG")
                    Text("I worked for 4 years at CISCO as security specialist")
                    Text("Developed my own application")
                    Text("Currently working at Opsec as backend developer")
                        .padding(.bottom, 20)
                }
                .frame(maxWidth: 300)
                VStack(alignment: .leading, spacing: 20){
                    Text("Languages: Kotlin, Java, Swift, C++")
                    Text("Fullstack developer")
                    Text("Security specialist")
                    Text("Fluent in english and spanish")
                        .padding(.bottom, 20)
                }
                .frame(maxWidth: 300)
            }
        }
        .background(.mint)
        .clipShape(RoundedRectangle(cornerRadius: 20.0))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .foregroundStyle(Color.purple)
        
        
        
    }
    
    
}

#Preview {
    curriculumView()
}
