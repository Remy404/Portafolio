import SwiftUI

struct whoView: View {
    var body: some View {
        VStack(alignment: .center, spacing: 10) {
            Image("stockman")
                .imageScale(.large)
                .clipShape(Circle())
                .padding(40)
            Text("My name is John Doe")
                .font(.largeTitle)
                .padding(.bottom, 20)
            Text("Who am I")
                .font(.title)
            Text("Im 32 years old")
            Text("I played volleyball 3 years")
            Text("My favourite food is pizza")
            Text("My favourite band is incubus")
            Text("")
        }
        .background(.cyan)
        .clipShape(RoundedRectangle(cornerRadius: 20.0))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .foregroundStyle(Color.black)
    }
}

#Preview {
    whoView()
}
