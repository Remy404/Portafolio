//
//  artModel.swift
//  ObrasDeArte
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI
import Foundation

struct artmodel: Hashable, Codable, Identifiable {
    var artist: String
    var title: String
    var description: String
    var id: Int
    private var imageName: String
        var image: Image {
            Image(imageName)
    }
}
