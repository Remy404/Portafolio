//
//  artList.swift
//  ObrasDeArte
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI

struct artList: View {
    var body: some View {
        NavigationSplitView {
            List(artmodels) { artwork in
                NavigationLink {
                    detailView(art: artwork)
                } label: {
                    listRow(art: artwork)
                }
            }
            .navigationTitle("Artworks")
        } detail: {
            Text("Select a painting")
        }
    }
}

#Preview {
    artList()
}
