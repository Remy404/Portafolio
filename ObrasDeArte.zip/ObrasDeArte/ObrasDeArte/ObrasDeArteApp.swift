//
//  ObrasDeArteApp.swift
//  ObrasDeArte
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI

@main
struct ObrasDeArteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
