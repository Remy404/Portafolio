//
//  listRow.swift
//  ObrasDeArte
//
//  Created by Alumno on 02/05/24.
//

import SwiftUI

struct listRow: View {
    var art: artmodel    
    var body: some View {
        HStack {
            art.image
                .resizable()
                .frame(width: 80, height: 80)
            VStack(alignment: .leading) {
                Text(art.title)
                    .font(.title)
                Text(art.artist)
            }
            Spacer()
        }
    }
}

#Preview {
    Group {
        listRow(art: artmodels[0])
        listRow(art: artmodels[1])
    }
}
