//
//  detailView.swift
//  ObrasDeArte
//
//  Created by Alumno on 02/05/24.
//
import SwiftUI

struct detailView: View {
    var art: artmodel
    var body: some View {
        GeometryReader { geometry in
            ScrollView{
                VStack {
                    art.image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: geometry.size.width, height: geometry.size.height / 2)
                        .clipped()
                    Divider()
                    Text(art.title)
                        .bold()
                        .font(.title)
                        .frame(maxWidth: 300)
                        .cornerRadius(10)
                    Text("Artist: \(art.artist)" )
                        .font(.title)
                        .padding(.bottom)
                    Text(art.description)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal)
                    Spacer()
                }
            }.background(.gray)
                .foregroundColor(.white)
                }
    }
}

#Preview {
    Group {
        detailView(art: artmodels[1])
    }
}
